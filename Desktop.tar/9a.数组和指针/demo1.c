#include <stdio.h>


int main(void){

    int a[2];

    a[0] = 10;
    a[1] = 20;

    printf("%d\n%d\n", a[0], a[1]);

    return 0;
}

