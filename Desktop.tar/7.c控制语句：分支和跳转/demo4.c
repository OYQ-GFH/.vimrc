#include <stdio.h>

int main(void){
    
    int a = 1;

    while (a){
        scanf("%d", &a);
        if (0 < a && a < 10)
            printf("yes!\n");
        else
            goto print;
    }
    print : printf("no!\n");
    return 0;
}
