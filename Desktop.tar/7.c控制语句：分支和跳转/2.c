#include <stdio.h>


int main(void){

    int num;
    scanf("%d", &num);
    if (num > 6)
        if (num < 12)
            printf("yes\n");
    else
        printf("no\n");

    return 0;
}
