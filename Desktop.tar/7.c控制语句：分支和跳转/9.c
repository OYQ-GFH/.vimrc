#include <stdio.h>
#include <ctype.h>


int main(void){

    char ch;

    printf("Give me a letter of the alpgabet, and I will give ");
    printf("an animal name\nbeginning with that letter.\n");
    printf("Please type in a letter; type # to end my act.n");
    while ((ch = getchar()) != '#'){
        if ('\n' == ch)
            continue;
        if (islower(ch))
            switch(ch){
                case 'a':
                    printf("argli, awild sheep of Asia\n");
                    break;
                case 'b':
                    printf("babirusa, a wild pig of Malay\n");
                    break;
                case 'c':
                    printf("coati, racoonlike mammal\n");
                    break;
                case 'd':
                    printf("desman\n");
                    break;
                case 'e':
                    printf("e");
                    break;
                case 'f':
                    printf("f");
                    break;
                default:
                    printf("That's a stumper!\n");
                   
            }
        else
            printf("sdaiidsai\n");
        while (getchar() != '\n')
            continue;
        printf("sdadja\n");
    }
    printf("Bye!\n");

    return 0;

}
