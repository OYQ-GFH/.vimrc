#include <stdio.h>

int main(void){

    int num;
    scanf("%d", &num);
    switch (num){
        case 1:
            printf("不及格\n");
            break;
        case 2:
            printf("及格\n");
            break;
        case 3:
            printf("优秀\n");
            break;
        default:
            printf("输入有误");
    }
    return 0;
}
