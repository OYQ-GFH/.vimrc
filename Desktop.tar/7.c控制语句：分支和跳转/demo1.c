#include <stdio.h>
#include <stdlib.h>


int main(void){

    int random;
    int true = 1;
    int num;

    while (true){
        random = rand() %6;
        printf("猜一猜数字吧: ");
        scanf("%d", &num);
        if (num == random){
            printf("你猜对啦\n");
            break;
        }
        else{
            printf("很遗憾你没猜对\n");
            random = rand() %6;
        }
    }
    return 0;
}
