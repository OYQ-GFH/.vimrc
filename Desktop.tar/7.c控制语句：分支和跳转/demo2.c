#include <stdio.h>
#include <stdbool.h>

int a();
int b();

int main(void){

    int num1 = 6;
    int num2, falg;

    while (true){
        scanf("%d", &num2);
        falg = (num1 < num2) ? a(num2) : b(num2);
        if (falg)
            break;
        else
            continue;
    }

    return 0;

}

int a(int num){
    printf("%d yes!\n", num);
    return true;
}

int b(int num){
    printf("%d no!\n", num);
    return false;
}

