#include <stdio.h>

int main(void){

    const int a[8];
    char num;

    while (scanf("%c", &num)){
        printf("%d", num);
    }

    return 0;
    
}
