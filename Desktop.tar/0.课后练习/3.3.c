#include <stdio.h>


int main(void){

    printf("\aStartled by the sudden sound, Sally shouted,\n");
    printf("\"By the Great pumpkin, what was that!\"\n");

    return 0;
}
