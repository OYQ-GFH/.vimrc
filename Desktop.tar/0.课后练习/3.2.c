#include <stdio.h>


int main(void){

    int a;
    printf("请输入一个ASCLL码: ");
    scanf("%d", &a);
    printf("%c\n", a);

    return 0;
}
