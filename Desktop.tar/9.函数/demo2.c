#include <stdio.h>


int main(void){

    int a = 100;
    int * b;
    int c;

    b = &a;
    c = *b;
    
    printf("a = %d\n&a = %p\nc = %d\n", a, b, c);

    return 0;
}
