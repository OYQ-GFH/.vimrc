#include <stdio.h>


int main(void){

    int num = 1;
    int * a = &num;
    int  * b = *a;

    printf("%d%p%p", num, a, b);

    return 0;
}
