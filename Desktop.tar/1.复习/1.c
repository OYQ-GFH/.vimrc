#include <stdio.h>

int main(void)
{
    short a = 10;
    int b = 10;
    long c = 10l;
    long long d = 10ll;

    printf("a = %lu\n", sizeof(a));
    printf("b = %lu\n", sizeof(b));
    printf("c = %lu\n", sizeof(c));
    printf("d = %lu\n", sizeof(d));

    printf("a = %hd\n", a);
    printf("b = %d\n", b);
    printf("c = %ld\n", c);
    printf("d = %lld\n", d);

    return 0;

}
