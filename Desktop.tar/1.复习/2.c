#include <stdio.h>


int main(void)
{
    char a;

    a = getchar();

    switch (a){
        case '1':
            printf("ok\n");
            break;
        case '2':
            printf("not ok\n");
            break;
        default:
            printf("are you ok?\n");
    }
    return 0;
}
