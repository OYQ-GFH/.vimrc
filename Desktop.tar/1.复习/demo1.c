#include <stdio.h>
#define t "True"

int main(void)
{
    float a = 3.14;
    float b = 3.14f;
    double c = 3.14;
    double d = b ? b < c : c > b;
    
    printf("a = %lubt\n", sizeof(a));
    printf("b = %lubt\n", sizeof(b));
    printf("c = %lubt\n", sizeof(c));

    return 0;
}
