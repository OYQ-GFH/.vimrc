#include <stdio.h>


int main(void){

    int num;

    num = getchar();
    putchar(num);

    return 0;
}
